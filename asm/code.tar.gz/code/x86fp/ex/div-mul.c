double x1 = 1.2;
double x2 = 3.4;
double x3 = 5.0;
double x4 = 6.0;
double x5 = 7.0;
double x6 = 8.9;

int main(void)
{
  double z = (x1 + x2) / (x3 - x4) * (x5 - x6);
	return 0;
}
