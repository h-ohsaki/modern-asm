#!/bin/sh

for i in `seq 5`
do
    echo -n "___\v|\v\b|\v\b|"
done
echo
